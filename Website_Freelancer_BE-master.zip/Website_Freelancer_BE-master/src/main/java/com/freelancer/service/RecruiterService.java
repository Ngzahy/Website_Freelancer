package com.freelancer.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.freelancer.model.Recruiter;
import com.freelancer.repository.RepositoryRecruiter;

@Service
public class RecruiterService extends EntityService<Recruiter, Integer> {

	@Autowired
	private RepositoryRecruiter repository;

	public Optional<Recruiter> getByAccountId(Integer id) {
		return repository.findByProfile_Account_Id(id);
	}
}
