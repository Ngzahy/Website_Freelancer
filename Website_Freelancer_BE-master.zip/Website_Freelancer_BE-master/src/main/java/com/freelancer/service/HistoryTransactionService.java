package com.freelancer.service;

import org.springframework.stereotype.Service;

import com.freelancer.model.HistoryTransaction;

@Service
public class HistoryTransactionService extends EntityService<HistoryTransaction, Integer> {

}
