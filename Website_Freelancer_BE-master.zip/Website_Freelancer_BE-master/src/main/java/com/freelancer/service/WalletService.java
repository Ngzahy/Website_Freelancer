package com.freelancer.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.freelancer.model.Wallet;
import com.freelancer.repository.RepositoryWallet;

@Service
public class WalletService extends EntityService<Wallet, Integer> {
	@Autowired
	RepositoryWallet repository;
	
	public Optional<Wallet> getByRecruiterId(Integer id){
		return repository.findByProfile_Recruiter_Id(id);
	}
}
