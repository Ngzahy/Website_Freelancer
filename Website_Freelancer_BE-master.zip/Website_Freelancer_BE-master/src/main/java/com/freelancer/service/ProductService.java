package com.freelancer.service;

import org.springframework.stereotype.Service;

import com.freelancer.model.Product;

@Service
public class ProductService extends EntityService<Product, Integer> {

}
