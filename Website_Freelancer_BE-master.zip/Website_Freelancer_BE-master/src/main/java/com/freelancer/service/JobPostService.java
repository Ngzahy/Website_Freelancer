package com.freelancer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.freelancer.model.JobPost;
import com.freelancer.repository.RepositoryJobPost;
import com.freelancer.utils.State;

@Service
public class JobPostService extends EntityService<JobPost, Integer> {
	@Autowired
	RepositoryJobPost repository;

	public Page<JobPost> getByStatus(Integer status, Pageable pageable) {

		return repository.findByStatus(
				status != null ? status : State.JobPost.PUBLISHED, pageable);
	}

	public Page<JobPost> page(Integer id, Pageable pageable) {
		return repository.findByRecruiter_Profile_Account_Id(id, pageable);

	}

	public Page<JobPost> search(String keyword, Pageable pageable) {
		return repository.searchJobPosts(keyword, pageable);
	}

	public Page<JobPost> getActiveByAccountId(Integer id, Pageable pageable) {
		return repository.findByStatusInAndRecruiter_Profile_Account_Id(
				List.of(State.JobPost.PUBLISHED, State.JobPost.FINISHED,
						State.JobPost.STARTED),
				id, pageable);
	}

	public Page<JobPost> getDraftByAccountId(Integer id, Pageable pageable) {
		return repository.findByStatusInAndRecruiter_Profile_Account_Id(
				List.of(State.JobPost.EDITING), id, pageable);
	}

	public Page<JobPost> getActive(Pageable pageable) {
		return repository.findByStatusIn(List.of(State.JobPost.PUBLISHED,
				State.JobPost.FINISHED, State.JobPost.STARTED), pageable);
	}
	
	public Page<JobPost> searchWithStatus(String keyword,
			Pageable pageable) {
		return repository.searchJobPostsWithStatus(
				keyword, List.of(State.JobPost.PUBLISHED),
				pageable);
	}

}
