package com.freelancer.service;

import org.springframework.stereotype.Service;

import com.freelancer.model.Permission;

@Service
public class PermissionService extends EntityService<Permission, Integer> {}
