package com.freelancer.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.freelancer.model.Freelancer;
import com.freelancer.repository.RepositoryFreelancer;

@Service
public class FreelancerService extends EntityService<Freelancer, Integer> {
	@Autowired
	private RepositoryFreelancer repository;
	
	public Optional<Freelancer> findByAccountId(Integer id) {
		return repository.findByProfile_Account_Id(id);
	}
}
