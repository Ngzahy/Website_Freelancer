package com.freelancer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.freelancer.dto.ApplyDTO;
import com.freelancer.model.Apply;
import com.freelancer.model.JobPost;
import com.freelancer.service.ApplyService;
import com.freelancer.service.JobPostService;
import com.freelancer.utils.State;

@RestController
@RequestMapping("/applies")
public class ApplyController
		extends
			EntityController<Apply, ApplyDTO, Integer> {

	private static final String ID = "id";

	@Autowired
	private ApplyService service;

	@Autowired
	private JobPostService jobPostService;

	@GetMapping("/jobpost/{id}")
	public Page<ApplyDTO> getAppliesByJobPost(@PathVariable Integer id,
			@RequestParam(defaultValue = "1") Integer page,
			@RequestParam(defaultValue = "10") Integer size,
			@RequestParam(required = false) String[] search,
			@RequestParam(required = false) String[] sort) {

		Pageable pageable = PageRequest.of(--page, size,
				Sort.by(Sort.Direction.ASC, "id"));

		return service.getByJobPostId(id, pageable).map((e) -> e.toDto());
	}

	@PutMapping("/select/{id}")
	public ResponseEntity<String> select(@PathVariable Integer id) {

		Apply apply = service.getById(id).orElse(null);

		if (apply == null) {
			return ResponseEntity.badRequest().body("Không tìm thấy yêu cầu!");
		}

		service.hiddenAllByJobPostId(apply.getJobPost().getId());

		apply.setStatus(State.Apply.WORKING);
		service.update(apply);

		JobPost jobPost = jobPostService.getById(apply.getJobPost().getId())
				.orElse(null);

		if (jobPost == null) {
			return ResponseEntity.badRequest().body("Không tìm thấy bài đăng!");
		}

		jobPost.setStatus(State.JobPost.STARTED);
		jobPostService.update(jobPost);
		return ResponseEntity.ok().body("Chọn yêu cầu thành công!");

	}

	@GetMapping("/working/{id}")
	public ApplyDTO getWorkingByJobPost(@PathVariable Integer id) {
		Apply apply = service.getWorkingByJobPostId(id).orElse(null);
		return apply != null ? apply.toDto() : null;
	}

}
