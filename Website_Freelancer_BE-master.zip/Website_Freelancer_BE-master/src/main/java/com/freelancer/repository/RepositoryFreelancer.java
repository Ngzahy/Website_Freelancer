package com.freelancer.repository;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.freelancer.model.Freelancer;

@Repository
public interface RepositoryFreelancer extends RepositoryEntity<Freelancer, Integer> {
	public Optional<Freelancer> findByProfile_Account_Id(Integer id);
}
