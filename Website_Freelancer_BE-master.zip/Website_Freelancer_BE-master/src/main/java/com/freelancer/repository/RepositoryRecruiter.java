package com.freelancer.repository;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.freelancer.model.Recruiter;

@Repository
public interface RepositoryRecruiter
		extends
			RepositoryEntity<Recruiter, Integer> {

	public Optional<Recruiter> findByProfile_Account_Id(Integer id);
}
