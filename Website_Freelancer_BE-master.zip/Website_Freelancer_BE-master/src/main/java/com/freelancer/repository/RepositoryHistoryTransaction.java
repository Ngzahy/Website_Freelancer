package com.freelancer.repository;

import org.springframework.stereotype.Repository;

import com.freelancer.model.HistoryTransaction;

@Repository
public interface RepositoryHistoryTransaction extends RepositoryEntity<HistoryTransaction, Integer> {

}
